# Resume Bullets & Interview Prep

Paste-ready project bullets, the new skills you can now legitimately claim, and
the exact claims to be ready to defend in an interview. Written to be truthful:
nothing here says you ran an enterprise 24/7 SOC or shipped these to production.

---

## PROJECTS section (drop-in replacement for your resume)

**SOC Detection Engineering Lab** — *Sigma, Splunk SPL, Sentinel KQL, MITRE ATT&CK*
- Authored and tuned 10 SIEM detections in Sigma, Splunk SPL, and Microsoft
  Sentinel KQL against adversary-emulation datasets, each mapped to MITRE ATT&CK.
- Documented alert-to-verdict investigations with triage steps, escalation
  criteria, and false-positive logic.

**Phishing Triage Analyzer** — *Python, VirusTotal, AbuseIPDB, SPF/DKIM/DMARC*
- Built a Python tool that parses .eml files, extracts and defangs IOCs,
  evaluates SPF/DKIM/DMARC, enriches indicators via VirusTotal and AbuseIPDB, and
  outputs an explainable risk score with an LLM-assisted analyst summary.

**Agentic AI SOC Triage Assistant** — *Python, MITRE ATT&CK, local LLM*
- Developed an analyst-in-the-loop triage assistant that maps alerts to MITRE
  ATT&CK, computes an explainable priority score, enriches IOCs, and drafts
  LLM-assisted triage notes with human approval gating on all response actions.

**AI Security — LLM Prompt-Injection Assessment** — *OWASP LLM Top 10, Python*
- Performed a prompt-injection assessment of an LLM chatbot, built an automated
  test harness mapping findings to the OWASP LLM Top 10, and implemented
  input/output guardrails that eliminated secret leakage in testing.

**SOAR IOC Enrichment Tool** — *Python, Shuffle, VirusTotal/AbuseIPDB/OTX*
- Built a Python IOC-enrichment tool that auto-detects indicator types and
  aggregates multi-source threat-intel reputation into a single risk verdict,
  designed to plug into a Shuffle SOAR workflow.

---

## New skills you can now add to the SKILLS section (all defensible)
- **Detection Engineering:** Sigma rule authoring, detection-as-code, ATT&CK
  coverage mapping
- **Email Security:** phishing triage, header analysis, SPF/DKIM/DMARC
- **Threat Intel:** VirusTotal, AbuseIPDB, AlienVault OTX enrichment
- **AI Security:** OWASP LLM Top 10, prompt-injection testing, LLM guardrails
- **SOAR / Automation:** Shuffle, Python enrichment workflows, analyst-in-the-loop AI

---

## Claims to be ready to explain (interviewers will ask)

**Detection lab**
- Be able to walk through one rule end to end (e.g., LSASS access, Sysmon EID 10,
  which GrantedAccess masks and why, how you'd cut false positives).
- Know the difference between Sigma, SPL, and KQL and why detection-as-code
  (Sigma) is portable across SIEMs.
- Say plainly: this is a lab on public datasets, not production SOC volume.

**Phishing analyzer**
- Explain SPF vs DKIM vs DMARC in one sentence each and what a DMARC `p=reject`
  fail means.
- Explain why you defang IOCs and why attachments are hashed, never opened.

**Agentic AI triage**
- The key point: *why analyst-in-the-loop*. A probabilistic model must not
  auto-isolate hosts or disable accounts — it summarizes and ranks; a human
  approves. The priority score is computed in code so it's auditable.

**AI security / LLM**
- Name 3 OWASP LLM risks (LLM01 Prompt Injection, LLM02 Sensitive Info
  Disclosure, LLM07 System-Prompt Leakage) and the layered mitigations.
- The root-cause insight: don't put secrets in the model's context at all.

**SOAR enrichment**
- Describe how this fits a real workflow: alert → enrich → branch on verdict →
  auto-ticket or auto-close, with a human for anything destructive.

---

## Honest framing reminders
- These are **personal lab projects**, not employment. Present them under
  PROJECTS, not EXPERIENCE.
- Keep the language "adversary-emulation datasets" and "lab" — accurate and it
  actually sounds more competent than overclaiming.
- Do not merge these into your Impact Partners Studio role.
