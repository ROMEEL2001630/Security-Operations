# Romeel Bhavsar — SOC & AI Security Portfolio

Five hands-on projects that demonstrate practical **Security Operations Center**
and **AI security** skills: detection engineering, phishing triage, AI-assisted
alert triage, LLM security testing, and SOAR automation. Everything runs on
**free or community tooling** and is built to be reproducible and defensible in
an interview.

**Target roles:** SOC Analyst I/II · Cybersecurity Analyst · Security Operations
Analyst · Threat Detection / SIEM Analyst · Junior Security Engineer.

---

## Projects

| # | Project | What it proves | Key tools |
|---|---------|----------------|-----------|
| 01 | [Detection Engineering Lab](01-detection-engineering-lab/) | Authoring & tuning SIEM detections mapped to MITRE ATT&CK, with investigation writeups | Sigma, Splunk SPL, Sentinel KQL, ATT&CK |
| 02 | [Phishing Triage Analyzer](02-phishing-triage-analyzer/) | End-to-end phishing triage: IOC extraction, SPF/DKIM/DMARC, TI enrichment, AI summary | Python, VirusTotal, AbuseIPDB, Ollama |
| 03 | [Agentic AI SOC Triage Assistant](03-agentic-ai-soc-triage/) | Analyst-in-the-loop alert triage, ATT&CK mapping, explainable priority, LLM notes | Python, MITRE ATT&CK, Ollama |
| 04 | [AI Security: LLM Assessment](04-ai-security-llm-assessment/) | Prompt-injection testing & mitigation mapped to OWASP LLM Top 10 | Python, OWASP LLM Top 10 |
| 05 | [SOAR IOC Enrichment](05-soar-ioc-enrichment/) | Security automation: multi-source IOC enrichment with an aggregated verdict | Python, Shuffle, VT/AbuseIPDB/OTX |

Each project folder has its own README with run instructions, the skills it
demonstrates, and a truthful resume line.

## Skills covered across the portfolio
SIEM detection authoring (Sigma / SPL / KQL) · MITRE ATT&CK mapping · alert
triage & prioritization · false-positive tuning · phishing & email header
analysis · threat-intel enrichment (VirusTotal, AbuseIPDB, OTX) · incident
investigation documentation · AI-assisted triage (analyst-in-the-loop) · LLM
security / OWASP LLM Top 10 · SOAR automation · Python.

## Requirements
- **Python 3.10+** (all scripts run on the standard library; `requests` only
  needed for live API/LLM calls).
- Optional free tooling: **Splunk Free**, **Microsoft Sentinel** trial,
  **Wazuh**, **Sysmon**, **Ollama** (local LLM), **Shuffle** (SOAR).
- Optional free API keys: AbuseIPDB, VirusTotal, AlienVault OTX.

## Quick verification (offline, no keys)
```bash
python 02-phishing-triage-analyzer/phish_triage.py \
    02-phishing-triage-analyzer/sample_emails/sample_phish.eml
python 03-agentic-ai-soc-triage/soc_triage_assistant.py \
    03-agentic-ai-soc-triage/sample_alerts.json
python 04-ai-security-llm-assessment/tests/injection_tests.py
python 05-soar-ioc-enrichment/ioc_enrich.py --file 05-soar-ioc-enrichment/iocs.txt
```

## Contact
Romeel Bhavsar · romeelcybersec@gmail.com · linkedin.com/in/romeel-rb
Open to relocation based on the position's office location.

> Note: All datasets are public/sample data and all secrets are fake. These
> projects are for learning and demonstration. Nothing here should be run
> against systems you do not own.
