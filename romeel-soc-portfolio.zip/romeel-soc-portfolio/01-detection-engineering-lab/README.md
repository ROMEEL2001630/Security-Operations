# Detection Engineering Lab

Ten SOC detections written in **Sigma**, **Splunk SPL**, and **Microsoft
Sentinel KQL**, each mapped to **MITRE ATT&CK** and paired with analyst
investigation writeups. Built to demonstrate hands-on detection authoring,
tuning, and triage using free datasets.

## Why this exists
Most entry-level portfolios describe tools. This one shows the actual work of a
SOC analyst: writing a rule, mapping it to adversary behavior, running it against
attack data, and documenting the investigation and false-positive logic.

## What's inside
```
detections/
  sigma/       10 portable Sigma rules (one file per detection)
  splunk/      detections.spl  — all 10 as Splunk SPL
  sentinel/    detections.kql  — all 10 as Sentinel/Defender KQL
investigations/ 3 full alert-to-verdict writeups
mitre-attack-mapping.md  coverage table across 6 ATT&CK tactics
```

## Detections
| # | Detection | Technique |
|---|-----------|-----------|
| 01 | PowerShell encoded command | T1059.001 |
| 02 | LSASS memory access | T1003.001 |
| 03 | Scheduled task creation | T1053.005 |
| 04 | Registry Run key persistence | T1547.001 |
| 05 | Remote thread injection | T1055 |
| 06 | Failed-logon brute force | T1110 |
| 07 | AWS root console login | T1078.004 |
| 08 | Shadow copy deletion (ransomware) | T1490 |
| 09 | certutil download | T1105 |
| 10 | Regsvr32 Squiblydoo | T1218.010 |

## How to reproduce (all free)
1. **Build a lab VM** (Windows 10/11) and install **Sysmon** with a good config
   (SwiftOnSecurity or Olaf Hartong).
2. **Generate telemetry** with **Atomic Red Team** (`Invoke-AtomicTest`) for each
   technique above, or import ready-made **EVTX-ATTACK-SAMPLES**, or load the
   **Splunk BOTS v3** dataset.
3. **Ingest** into **Splunk Free** (500 MB/day) or a **Sentinel** free trial /
   the Microsoft Sentinel training lab.
4. **Run the queries** in `detections/` and validate they fire on the attack
   events but not on baseline activity.
5. **Convert Sigma → your SIEM** with the `sigma` CLI:
   `sigma convert -t splunk detections/sigma/` (or `-t microsoft365defender`).

## Skills demonstrated
SIEM detection authoring (SPL/KQL/Sigma) · MITRE ATT&CK mapping · alert triage ·
false-positive tuning · investigation documentation · Windows/Sysmon &
CloudTrail log analysis.

## Resume line (truthful)
> Authored and tuned 10 SIEM detections in Sigma, Splunk SPL, and Sentinel KQL
> against adversary-emulation datasets, mapped to MITRE ATT&CK, with documented
> triage steps and false-positive logic.

*Author: Romeel Bhavsar*
