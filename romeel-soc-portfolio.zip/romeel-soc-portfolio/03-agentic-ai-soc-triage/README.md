# Agentic AI SOC Triage & Response Assistant

Reads a batch of SIEM alerts, enriches their entities, maps each to **MITRE
ATT&CK**, computes an **explainable priority score**, and drafts an analyst
**triage note** — optionally with a **local LLM (Ollama)** or a hosted one.
Every suggested response action is a checklist item that **requires analyst
approval**. The AI accelerates triage; it never auto-remediates.

> This is the concrete, runnable version of the "Agentic AI SOC Triage" project.
> It is deliberately analyst-in-the-loop, which is the design real SOCs deploy.

## Run it (offline, no keys)
```bash
python soc_triage_assistant.py sample_alerts.json
```
You get a priority-sorted queue plus a triage note and approval checklist per
alert. Expected top of queue: the **AWS root login** (crown-jewel asset) and
**shadow-copy deletion** (ransomware / Impact) as P1.

## With a local LLM (free)
```bash
pip install -r requirements.txt
ollama run llama3
python soc_triage_assistant.py sample_alerts.json --llm ollama --out notes/
```

## How priority is scored (explainable, in code)
`severity` + `asset_criticality` + high-impact ATT&CK tactic + threat-intel
signal on any IP → 0-100 → P1..P4. The score is computed deterministically so
the queue ordering is auditable; the LLM only writes prose.

## Input schema
Each alert is a JSON object with `id, timestamp, rule, severity, host, user,
asset_criticality, technique, entities{ips,hashes,domains}, raw`. See
`sample_alerts.json`.

## Skills demonstrated
Alert triage & prioritization · MITRE ATT&CK mapping · IOC enrichment · secure
LLM integration (guardrails, no auto-action) · Python automation.

## Resume line (truthful)
> Built an analyst-in-the-loop SOC triage assistant in Python that maps alerts
> to MITRE ATT&CK, computes an explainable priority score, enriches IOCs, and
> drafts LLM-assisted triage notes with human-approval gating on all response
> actions.

## Interview talking point
Be ready to explain *why* it's analyst-in-the-loop: a probabilistic model must
not auto-isolate hosts or disable accounts; it summarizes and ranks, a human
approves. That judgment is the point of the project.

*Author: Romeel Bhavsar*
