# Phishing Triage Analyzer

A Python tool that turns a raw `.eml` into a SOC-ready triage report: it parses
headers and bodies, extracts IOCs, runs SPF/DKIM/DMARC and heuristic checks,
optionally enriches indicators against free threat-intel APIs, and can generate
an analyst summary with a **local** LLM (Ollama) or a hosted one.

Phishing triage is one of the most common Tier-1 SOC tasks. This project shows
the full workflow end to end — and does it **analyst-in-the-loop** (recommends a
verdict, never auto-actions).

## Features
- Parses multipart email safely; never executes attachments (hashes them).
- Extracts URLs, external IPs (from `Received`), sender/reply-to domains,
  attachment names + **SHA-256**.
- Reads **SPF / DKIM / DMARC** results and flags Reply-To vs From mismatch.
- Explainable heuristic **risk score (0-100)** with reasons.
- Output IOCs are **defanged** (`hxxp`, `[.]`) for safe pasting into tickets.
- Optional enrichment: **AbuseIPDB** (IPs) + **VirusTotal** (domains).
- Optional **LLM summary** via Ollama (free/local) or OpenAI.
- Emits a Markdown report and a JSON IOC bundle.

## Quick start (offline, no keys needed)
```bash
python phish_triage.py sample_emails/sample_phish.eml --out report.md --json iocs.json
```
Expected on the bundled sample: **Malicious / High** — SPF & DMARC fail,
Reply-To mismatch, lookalike domain `micros0ft-security.com`, raw-IP link, and a
double-extension `.html.exe` attachment.

## With enrichment + local LLM
```bash
pip install -r requirements.txt
cp config.example.env .env      # add your free API keys
export $(grep -v '^#' .env | xargs)
ollama run llama3               # in another terminal
python phish_triage.py msg.eml --enrich --llm ollama --out report.md
```

## Where to get real samples to practice on (free)
- Your own spam folder (export as `.eml`).
- **PhishTank** and **URLhaus** (malicious URLs).
- **MalwareBazaar** (malicious attachments — handle in an isolated VM only).

## Skills demonstrated
Email header analysis · IOC extraction & enrichment · SPF/DKIM/DMARC ·
threat-intel APIs · Python automation · analyst-in-the-loop AI.

## Resume line (truthful)
> Built a Python phishing-triage tool that parses .eml files, extracts and
> enriches IOCs (AbuseIPDB/VirusTotal), evaluates SPF/DKIM/DMARC, and produces
> an LLM-assisted analyst summary with an explainable risk score.

## Safety notes
- Attachments are hashed, never opened. Detonate real malware only in an
  isolated VM.
- Keep API keys in `.env` (git-ignored). Free tiers are rate-limited.

*Author: Romeel Bhavsar*
